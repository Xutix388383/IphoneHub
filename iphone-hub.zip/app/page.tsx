import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { DownloadIcon } from "lucide-react"
import { sideloadIPADownloads, directInstallIPADownloads } from "@/lib/tools" // Import the specific download lists

export default function Component() {
  return (
    <div className="min-h-screen bg-gray-950 text-gray-50 antialiased">
      <header className="flex items-center justify-between px-4 py-4 md:px-6 lg:px-8 border-b border-gray-800">
        <h1 className="text-2xl font-extrabold tracking-tight text-crimson-light">iPhone Hub</h1>
        <nav className="hidden md:flex space-x-6">
          <a className="text-gray-300 hover:text-crimson-light transition-colors font-medium" href="#">
            Home
          </a>
          <a className="text-gray-300 hover:text-crimson-light transition-colors font-medium" href="#">
            About
          </a>
          <a className="text-gray-300 hover:text-crimson-light transition-colors font-medium" href="#">
            Contact
          </a>
        </nav>
      </header>
      <main className="container mx-auto px-4 py-8 md:py-12 lg:py-16">
        <div className="text-center mb-10">
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 text-gray-50">
            Your Ultimate iPhone Customization Hub
          </h2>
          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
            Explore a curated collection of tools, resources, and utilities to personalize and enhance your iPhone
            experience. Sleek, modern, and intuitive.
          </p>
        </div>

        <Tabs defaultValue="ipas" className="w-full">
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3 gap-2 mb-8 bg-gray-800 p-1 rounded-lg">
            <TabsTrigger
              value="ipas"
              className="data-[state=active]:bg-crimson-dark data-[state=active]:text-gray-50 data-[state=active]:shadow-sm text-gray-300 hover:text-crimson-light transition-colors font-semibold py-2 px-4 rounded-md"
            >
              IPAs
            </TabsTrigger>
            <TabsTrigger
              value="vpn-for-ios"
              className="data-[state=active]:bg-crimson-dark data-[state=active]:text-gray-50 data-[state=active]:shadow-sm text-gray-300 hover:text-crimson-light transition-colors font-semibold py-2 px-4 rounded-md"
            >
              VPN for iOS
            </TabsTrigger>
            <TabsTrigger
              value="jailbreak-tweaks"
              className="data-[state=active]:bg-crimson-dark data-[state=active]:text-gray-50 data-[state=active]:shadow-sm text-gray-300 hover:text-crimson-light transition-colors font-semibold py-2 px-4 rounded-md"
            >
              Jailbreak Tweaks
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ipas">
            <div className="space-y-8">
              <Card className="bg-gray-800 border-gray-700 text-gray-50">
                <CardHeader>
                  <CardTitle className="text-crimson-light text-2xl font-bold">IPA Links (Sideload)</CardTitle>
                  <CardDescription className="text-orange-400">
                    These IPAs require a sideloading tool (e.g., AltStore, Sideloadly) for installation.
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {sideloadIPADownloads.map((download, index) => (
                    <Card key={index} className="bg-gray-900 border-gray-700 text-gray-50">
                      <CardHeader>
                        <CardTitle className="text-lg font-semibold">{download.name}</CardTitle>
                        {download.description && (
                          <CardDescription className="text-gray-400">{download.description}</CardDescription>
                        )}
                      </CardHeader>
                      <CardContent>
                        <Link href={download.link} passHref target="_blank" rel="noopener noreferrer">
                          <Button className="w-full bg-crimson hover:bg-crimson-dark text-gray-50">
                            <DownloadIcon className="mr-2 h-4 w-4" /> Download
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700 text-gray-50">
                <CardHeader>
                  <CardTitle className="text-crimson-light text-2xl font-bold">Direct Install IPAs</CardTitle>
                  <CardDescription className="text-green-400">
                    These IPAs can be installed directly on your device without a computer or sideloading tools.
                  </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {directInstallIPADownloads.map((download, index) => (
                    <Card key={index} className="bg-gray-900 border-gray-700 text-gray-50">
                      <CardHeader>
                        <CardTitle className="text-lg font-semibold">{download.name}</CardTitle>
                        {download.description && (
                          <CardDescription className="text-gray-400">{download.description}</CardDescription>
                        )}
                      </CardHeader>
                      <CardContent>
                        <Link href={download.link} passHref target="_blank" rel="noopener noreferrer">
                          <Button className="w-full bg-crimson hover:bg-crimson-dark text-gray-50">
                            <DownloadIcon className="mr-2 h-4 w-4" /> Install
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="vpn-for-ios">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Link href="/tools/vpn-for-ios" passHref>
                <Card className="bg-gray-800 border-gray-700 text-gray-50 hover:border-crimson-light transition-colors cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-crimson-light text-2xl font-bold">VPN for iOS</CardTitle>
                    <CardDescription className="text-gray-400">
                      Secure your online activity and prevent IPA revokes.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300">
                      Explore VPN services designed to protect your privacy and keep your sideloaded apps functional.
                    </p>
                  </CardContent>
                </Card>
              </Link>
              {/* You can add more VPN related cards here if needed */}
            </div>
          </TabsContent>

          <TabsContent value="jailbreak-tweaks">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Link href="/tools/jailbreak-tweaks" passHref>
                <Card className="bg-gray-800 border-gray-700 text-gray-50 hover:border-crimson-light transition-colors cursor-pointer">
                  <CardHeader>
                    <CardTitle className="text-crimson-light text-2xl font-bold">Jailbreak Tweaks</CardTitle>
                    <CardDescription className="text-gray-400">
                      Explore powerful modifications for jailbroken iPhones.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300">
                      Unlock the full potential of your jailbroken iPhone with an extensive collection of tweaks.
                    </p>
                  </CardContent>
                </Card>
              </Link>
              {/* You can add more tweak categories here if needed */}
            </div>
          </TabsContent>
        </Tabs>
      </main>
      <footer className="px-4 py-6 md:px-6 lg:px-8 border-t border-gray-800 text-center text-gray-400 text-sm">
        © {new Date().getFullYear()} iPhone Hub. All rights reserved.
      </footer>
    </div>
  )
}
