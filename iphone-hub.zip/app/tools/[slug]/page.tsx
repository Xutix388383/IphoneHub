import Image from "next/image"
import Link from "next/link"
import { getToolBySlug, type Tool } from "@/lib/tools"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronLeftIcon } from "lucide-react"

interface ToolPageProps {
  params: {
    slug: string
  }
}

export default function ToolPage({ params }: ToolPageProps) {
  const tool: Tool | undefined = getToolBySlug(params.slug)

  if (!tool) {
    return (
      <div className="min-h-screen bg-gray-950 text-gray-50 flex flex-col items-center justify-center p-4">
        <h1 className="text-4xl font-bold text-crimson-light mb-4">Tool Not Found</h1>
        <p className="text-lg text-gray-400 mb-8">The tool you are looking for does not exist.</p>
        <Link href="/" passHref>
          <Button className="bg-crimson hover:bg-crimson-dark text-gray-50">
            <ChevronLeftIcon className="mr-2 h-4 w-4" /> Back to Hub
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-950 text-gray-50 antialiased">
      <header className="flex items-center justify-between px-4 py-4 md:px-6 lg:px-8 border-b border-gray-800">
        <Link href="/" passHref>
          <Button variant="ghost" className="text-gray-300 hover:text-crimson-light transition-colors">
            <ChevronLeftIcon className="mr-2 h-4 w-4" /> Back to Hub
          </Button>
        </Link>
        <h1 className="text-2xl font-extrabold tracking-tight text-crimson-light">iPhone Hub</h1>
        <div className="w-24"></div> {/* Placeholder for alignment */}
      </header>
      <main className="container mx-auto px-4 py-8 md:py-12 lg:py-16">
        <div className="text-center mb-10">
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 text-gray-50">{tool.name}</h2>
          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">{tool.description}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="bg-gray-800 border-gray-700 text-gray-50 mb-8">
              <CardHeader>
                <CardTitle className="text-crimson-light text-2xl font-bold">Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 leading-relaxed">{tool.longDescription}</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 text-gray-50 mb-8">
              <CardHeader>
                <CardTitle className="text-crimson-light text-2xl font-bold">Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside space-y-2 text-gray-300">
                  {tool.features.map((feature, index) => (
                    <li key={index}>{feature}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 text-gray-50 mb-8">
              <CardHeader>
                <CardTitle className="text-crimson-light text-2xl font-bold">Installation Guide</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="list-decimal list-inside space-y-2 text-gray-300">
                  {tool.installationSteps.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ol>
              </CardContent>
            </Card>

            {tool.screenshots && tool.screenshots.length > 0 && (
              <Card className="bg-gray-800 border-gray-700 text-gray-50 mb-8">
                <CardHeader>
                  <CardTitle className="text-crimson-light text-2xl font-bold">Screenshots</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {tool.screenshots.map((screenshot, index) => (
                    <div key={index} className="relative w-full h-48 rounded-lg overflow-hidden">
                      <Image
                        src={screenshot.src || "/placeholder.svg"}
                        alt={screenshot.alt}
                        layout="fill"
                        objectFit="cover"
                        className="rounded-lg"
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          <div className="lg:col-span-1">
            <Card className="bg-gray-800 border-gray-700 text-gray-50 mb-8 sticky top-8">
              <CardHeader>
                <CardTitle className="text-crimson-light text-2xl font-bold">Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-200 mb-2">Compatibility</h3>
                  <div className="flex flex-wrap gap-2">
                    {tool.compatibility.map((compat, index) => (
                      <Badge key={index} variant="secondary" className="bg-gray-700 text-gray-300 hover:bg-gray-600">
                        {compat}
                      </Badge>
                    ))}
                  </div>
                </div>
                {tool.downloadLink && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-200 mb-2">Download</h3>
                    <Link href={tool.downloadLink} passHref target="_blank" rel="noopener noreferrer">
                      <Button className="w-full bg-crimson hover:bg-crimson-dark text-gray-50">
                        Download {tool.name}
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <footer className="px-4 py-6 md:px-6 lg:px-8 border-t border-gray-800 text-center text-gray-400 text-sm">
        © {new Date().getFullYear()} iPhone Hub. All rights reserved.
      </footer>
    </div>
  )
}
